﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Kortspil
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// 
    /// Kortene er hentet fra https://acbl.mybigcommerce.com/52-playing-cards/
    /// </summary>
    public partial class MainWindow : Window
    {
        public string resultat;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int kortnummer = Convert.ToInt32(Kort.Text);
            string filnavn = FindBillede(kortnummer);
            string url = $"/Billeder/{filnavn}";
            Uri uri = new (url, UriKind.Relative);
            BitmapImage image = new(uri);
           
            Billede.Source = image;
            
        }

        private string FindBillede(int kortnummer)
        {

            switch (kortnummer)
            {
                case 1:
                    resultat = "Es-Spar.jpg";
                    break;
                case 2:
                    resultat = "2-Spar.jpg";
                    break;
                case 3:
                    resultat = "3-Spar.jpg";
                    break;
                case 4:
                    resultat = "4-Spar.jpg";
                    break;
                case 5:
                    resultat = "5-Spar.jpg";
                    break;
                case 6:
                    resultat = "6-Spar.jpg";
                    break;
                case 7:
                    resultat = "7-Spar.jpg";
                    break;
                case 8:
                    resultat = "8-Spar.jpg";
                    break;
                case 9:
                    resultat = "9-Spar.jpg";
                    break;
                case 10:
                    resultat = "10-Spar.jpg";
                    break;
                case 11:
                    resultat = "Knægt-Spar.jpg";
                    break;
                case 12:
                    resultat = "Dame-Spar.jpg";
                    break;
                case 13:
                    resultat = "Konge-Spar.jpg";
                    break;
                case 14:
                    resultat = "Es-Ruder.jpg";
                    break;
                case 15:
                    resultat = "2-Ruder.jpg";
                    break;
                case 16:
                    resultat = "3-Ruder.jpg";
                    break;
                case 17:
                    resultat = "4-Ruder.jpg";
                    break;
                case 18:
                    resultat = "5-Ruder.jpg";
                    break;
                case 19:
                    resultat = "6-Ruder.jpg";
                    break;
                case 20:
                    resultat = "7-Ruder.jpg";
                    break;
                case 21:
                    resultat = "8-Ruder.jpg";
                    break;
                case 22:
                    resultat = "9-Ruder.jpg";
                    break;
                case 23:
                    resultat = "10-Ruder.jpg";
                    break;
                case 24:
                    resultat = "Knægt-Ruder.jpg";
                    break;
                case 25:
                    resultat = "Dame-Ruder.jpg";
                    break;
                case 26:
                    resultat = "Konge-Ruder.jpg";
                    break;
                case 27:
                    resultat = "Es-Klør.jpg";
                    break;
                case 28:
                    resultat = "2-Klør.jpg";
                    break;
                case 29:
                    resultat = "3-Klør.jpg";
                    break;
                case 30:
                    resultat = "4-Klør.jpg";
                    break;
                case 31:
                    resultat = "5-Klør.jpg";
                    break;
                case 32:
                    resultat = "6-Klør.jpg";
                    break;
                case 33:
                    resultat = "7-Klør.jpg";
                    break;
                case 34:
                    resultat = "8-Klør.jpg";
                    break;
                case 35:
                    resultat = "9-Klør.jpg";
                    break;
                case 36:
                    resultat = "10-Klør.jpg";
                    break;
                case 37:
                    resultat = "Knægt-Klør.jpg";
                    break;
                case 38:
                    resultat = "Dame-Klør.jpg";
                    break;
                case 39:
                    resultat = "Konge-Klør.jpg";
                    break;
                case 40:
                    resultat = "Es-Hjerter.jpg";
                    break;
                case 41:
                    resultat = "2-Hjerter.jpg";
                    break;
                case 42:
                    resultat = "3-Hjerter.jpg";
                    break;
                case 43:
                    resultat = "4-Hjerter.jpg";
                    break;
                case 44:
                    resultat = "5-Hjerter.jpg";
                    break;
                case 45:
                    resultat = "6-Hjerter.jpg";
                    break;
                case 46:
                    resultat = "7-Hjerter.jpg";
                    break;
                case 47:
                    resultat = "8-Hjerter.jpg";
                    break;
                case 48:
                    resultat = "9-Hjerter.jpg";
                    break;
                case 49:
                    resultat = "10-Hjerter.jpg";
                    break;
                case 50:
                    resultat = "Knægt-Hjerter.jpg";
                    break;
                case 51:
                    resultat = "Dame-Hjerter.jpg";
                    break;
                case 52:
                    resultat = "Konge-Hjerter.jpg";
                    break;

                default:
                    
                    break;
            }
            return resultat;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
